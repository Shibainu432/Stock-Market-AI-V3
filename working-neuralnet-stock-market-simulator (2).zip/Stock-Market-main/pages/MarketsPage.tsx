import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Stock, StockListData, Region } from '../types';
import StockMarketTable from '../components/StockMarketTable';
import MarketHeatmap from '../components/MarketHeatmap';

type MarketListType = 'active' | 'trending' | 'gainers' | 'losers' | '52w_high' | '52w_low';
type ViewMode = 'table' | 'heatmap';

const MarketTab: React.FC<{ label: string; active: boolean; onClick: () => void }> = ({ label, active, onClick }) => (
    <button
        onClick={onClick}
        className={`px-4 py-2 text-sm font-semibold transition-colors border-b-2
            ${active 
                ? 'text-accent border-accent' 
                : 'text-gray-400 border-transparent hover:text-gray-200 hover:border-gray-500'
            }`}
    >
        {label}
    </button>
);

const ViewModeToggle: React.FC<{ viewMode: ViewMode; setViewMode: (mode: ViewMode) => void }> = ({ viewMode, setViewMode }) => (
    <div className="flex items-center bg-gray-900 rounded-md p-0.5">
        <button 
            onClick={() => setViewMode('table')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${viewMode === 'table' ? 'bg-accent text-white' : 'text-gray-400 hover:bg-gray-700'}`}
        >
            Table
        </button>
        <button
            onClick={() => setViewMode('heatmap')}
            className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${viewMode === 'heatmap' ? 'bg-accent text-white' : 'text-gray-400 hover:bg-gray-700'}`}
        >
            Heatmap
        </button>
    </div>
);

const RegionFilter: React.FC<{ selectedRegion: Region | 'Global'; onSelectRegion: (region: Region | 'Global') => void }> = ({ selectedRegion, onSelectRegion }) => {
    const regions: (Region | 'Global')[] = ['Global', 'North America', 'Europe', 'Asia'];
    return (
        <div className="flex items-center bg-gray-900 rounded-md p-0.5">
            {regions.map(region => (
                <button
                    key={region}
                    onClick={() => onSelectRegion(region)}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${selectedRegion === region ? 'bg-accent text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                >
                    {region}
                </button>
            ))}
        </div>
    );
};


const MarketsPage: React.FC<{
    stocks: Stock[];
    onSelectStock: (symbol: string) => void;
    searchQuery: string;
}> = ({ stocks, onSelectStock, searchQuery }) => {
    const [activeTab, setActiveTab] = useState<MarketListType>('active');
    const [viewMode, setViewMode] = useState<ViewMode>('table');
    const [selectedRegion, setSelectedRegion] = useState<Region | 'Global'>('Global');
    const [sortConfig, setSortConfig] = useState<{ key: keyof StockListData; direction: 'asc' | 'desc' } | null>(null);
    const [page, setPage] = useState(0);
    const PAGE_SIZE = 50;
    
    useEffect(() => {
        setSortConfig(null);
        setPage(0);
    }, [activeTab, selectedRegion]);

    const handleSort = useCallback((key: keyof StockListData) => {
        let direction: 'asc' | 'desc' = 'desc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'desc') {
            direction = 'asc';
        }
        setSortConfig({ key, direction });
    }, [sortConfig]);

    const filteredStocks = useMemo(() => {
        let data = selectedRegion === 'Global' ? stocks : stocks.filter(s => s.region === selectedRegion);
        if (searchQuery) {
            const lowerQuery = searchQuery.toLowerCase();
            data = data.filter(s => s.symbol.toLowerCase().includes(lowerQuery) || s.name.toLowerCase().includes(lowerQuery));
        }
        return data;
    }, [stocks, selectedRegion, searchQuery]);

    const stocksWithMetrics = useMemo(() => {
        // Optimization: Only compute metrics for current sort context or visible slice to save CPU
        // For 50k stocks, we'll compute simple metrics for all once, but limit heavy processing
        return filteredStocks.map(stock => {
            const history = stock.history;
            const current = history[history.length - 1];
            const prev = history[history.length - 2] || current;
            const price = current.close;
            const change = price - prev.close;
            const changePercent = prev.close > 0 ? (change / prev.close) : 0;
            return {
                ...stock,
                price,
                change,
                changePercent,
                volume: current.volume,
                marketCap: stock.sharesOutstanding * price,
                peRatio: stock.eps ? price / stock.eps : 0,
                high52w: price, // Simplified for bulk
                low52w: price,
                trendingScore: Math.abs(changePercent) * Math.log10(current.volume + 1),
            } as StockListData;
        });
    }, [filteredStocks]);
    
    const displayData = useMemo(() => {
        let sorted = [...stocksWithMetrics];

        if (sortConfig) {
            sorted.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
                if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
                return 0;
            });
        } else {
            switch (activeTab) {
                case 'active': sorted.sort((a, b) => b.volume - a.volume); break;
                case 'trending': sorted.sort((a, b) => b.trendingScore - a.trendingScore); break;
                case 'gainers': sorted.sort((a, b) => b.changePercent - a.changePercent); break;
                case 'losers': sorted.sort((a, b) => a.changePercent - b.changePercent); break;
                default: sorted.sort((a, b) => b.marketCap - a.marketCap); break;
            }
        }

        return sorted;
    }, [stocksWithMetrics, sortConfig, activeTab]);

    const visibleSlice = useMemo(() => {
        if (viewMode === 'heatmap') return displayData.slice(0, 2500); // Heatmap limit
        return displayData.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
    }, [displayData, page, viewMode]);

    const TABS: { key: MarketListType; label: string }[] = [
        { key: 'active', label: 'Most Active' },
        { key: 'trending', label: 'Trending' },
        { key: 'gainers', label: 'Top Gainers' },
        { key: 'losers', label: 'Top Losers' },
    ];
    
    return (
        <div>
            <div className="mb-4">
                <h1 className="text-2xl font-bold text-gray-200">
                    {selectedRegion} {TABS.find(t => t.key === activeTab)?.label}
                </h1>
                <p className="text-gray-400 font-mono text-xs uppercase tracking-widest">
                    Monitoring {stocks.length.toLocaleString()} active securities in high-frequency simulation.
                </p>
            </div>

            <div className="border-b border-gray-700 mb-4 flex justify-between items-center flex-wrap gap-2">
                <nav className="-mb-px flex space-x-2">
                    {TABS.map(tab => (
                        <MarketTab
                            key={tab.key}
                            label={tab.label}
                            active={activeTab === tab.key}
                            onClick={() => setActiveTab(tab.key)}
                        />
                    ))}
                </nav>
                <div className="flex items-center gap-2">
                     <RegionFilter selectedRegion={selectedRegion} onSelectRegion={setSelectedRegion} />
                     <ViewModeToggle viewMode={viewMode} setViewMode={setViewMode} />
                </div>
            </div>
            
             <div className="bg-gray-800 rounded-md border border-gray-700 overflow-hidden">
                {viewMode === 'table' ? (
                    <>
                        <StockMarketTable
                            stocks={visibleSlice}
                            onSelectStock={onSelectStock}
                            sortConfig={sortConfig}
                            onSort={handleSort}
                        />
                        <div className="p-4 bg-gray-900 flex justify-between items-center border-t border-gray-800">
                            <span className="text-xs text-gray-500 font-mono">
                                SHOWING {page * PAGE_SIZE + 1}-{Math.min((page + 1) * PAGE_SIZE, displayData.length)} OF {displayData.length.toLocaleString()}
                            </span>
                            <div className="flex gap-2">
                                <button 
                                    disabled={page === 0}
                                    onClick={() => setPage(p => p - 1)}
                                    className="px-4 py-1.5 text-[10px] font-black uppercase bg-gray-800 rounded disabled:opacity-20"
                                >PREV</button>
                                <button 
                                    disabled={(page + 1) * PAGE_SIZE >= displayData.length}
                                    onClick={() => setPage(p => p + 1)}
                                    className="px-4 py-1.5 text-[10px] font-black uppercase bg-gray-800 rounded disabled:opacity-20"
                                >NEXT</button>
                            </div>
                        </div>
                    </>
                ) : (
                    <div className="p-4">
                        <div className="mb-2 text-[10px] text-gray-500 font-mono uppercase text-center">
                            TREEMAP LIMITED TO TOP 2,500 SECURITIES BY MARKET CAP
                        </div>
                        <MarketHeatmap
                            stocks={visibleSlice}
                            onSelectStock={onSelectStock}
                        />
                    </div>
                )}
             </div>
        </div>
    );
};

export default MarketsPage;