import React, { useState, useMemo } from 'react';
import { Stock, Investor, SimplePriceDataPoint } from '../types.ts';
import PlayerTradeControls from './PlayerTradeControls.tsx';
import NeuralNetworkVisualizer from './NeuralNetworkVisualizer.tsx';
import CandlestickChart from './CandlestickChart.tsx';
import LineChart from './LineChart.tsx';
import PriceChart from './PriceChart.tsx';

const formatVolume = (volume: number): string => {
    if (volume > 1_000_000) return `${(volume / 1_000_000).toFixed(2)}M`;
    if (volume > 1_000) return `${(volume / 1_000).toFixed(1)}K`;
    return new Intl.NumberFormat().format(volume);
}

const StatItem: React.FC<{label: string, value: string | number}> = ({label, value}) => (
    <div className="flex justify-between items-center py-2 border-b border-gray-700 text-sm">
        <span className="text-gray-400 font-mono uppercase text-[10px] tracking-widest">{label}</span>
        <span className="font-mono text-gray-200 font-semibold">{value}</span>
    </div>
)

type TimeRange = '1D' | '1W' | '1M' | '1Y' | '5Y' | '10Y' | '20Y' | 'MAX';
type ChartType = 'line' | 'candle';

const TimeRangeButton: React.FC<{label: TimeRange, activeRange: TimeRange, onClick: (range: TimeRange) => void, disabled?: boolean}> = ({ label, activeRange, onClick, disabled }) => (
    <button 
        onClick={() => onClick(label)}
        disabled={disabled}
        className={`px-2 py-1.5 text-[10px] font-black uppercase tracking-widest transition-all rounded ${
            activeRange === label ? 'bg-accent text-white shadow-lg scale-105' : 'text-gray-500 hover:text-gray-300 bg-gray-900/50'
        } ${disabled ? 'opacity-20 cursor-not-allowed' : ''}`}
    >
        {label}
    </button>
);

const DetailedStockView: React.FC<{
  stock: Stock;
  allStocks: Stock[];
  onClose: () => void;
  player?: Investor | null;
  onPlayerBuy?: (symbol: string, shares: number) => void;
  onPlayerSell?: (symbol: string, shares: number) => void;
}> = ({ stock, allStocks, onClose, player, onPlayerBuy, onPlayerSell }) => {
  const [timeRange, setTimeRange] = useState<TimeRange>('1M');
  const [chartType, setChartType] = useState<ChartType>('candle');
  
  if (!stock) return null;

  const currentHistory = stock.history[stock.history.length - 1];
  const prevHistory = stock.history[stock.history.length - 2];
  if (!currentHistory || !prevHistory) return null;

  const currentPrice = currentHistory.close;
  const prevPrice = prevHistory.close;
  const volume = currentHistory.volume;

  const change = currentPrice - prevPrice;
  const changePercent = prevPrice !== 0 ? (change / prevPrice) * 100 : 0;
  const isUp = change >= 0;
  const changeColorClass = isUp ? 'text-gain' : 'text-loss';

  const high52w = stock.history.slice(-252).reduce((max, p) => Math.max(max, p.high), 0);
  const low52w = stock.history.slice(-252).reduce((min, p) => Math.min(min, p.low), Infinity);

  const chartData = useMemo(() => {
    const history = stock.history;
    let sliceLength = 30;
    switch (timeRange) {
        case '1D': sliceLength = 2; break;
        case '1W': sliceLength = 7; break;
        case '1M': sliceLength = 30; break;
        case '1Y': sliceLength = 252; break;
        case '5Y': sliceLength = 252 * 5; break;
        case '10Y': sliceLength = 252 * 10; break;
        case '20Y': sliceLength = 252 * 20; break;
        case 'MAX': sliceLength = history.length; break;
    }
    return history.slice(-Math.min(sliceLength, history.length));
  }, [stock.history, timeRange]);

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-xl flex justify-center z-50 p-4 overflow-y-auto" onClick={onClose}>
      <div className="bg-gray-900 w-full max-w-6xl rounded-lg border border-gray-800 shadow-2xl my-auto animate-fade-in flex flex-col h-[90vh]" onClick={e => e.stopPropagation()}>
        <div className="p-4 md:p-6 border-b border-gray-800 flex justify-between items-start bg-black/20">
            <div>
                <h2 className="text-3xl font-black text-gray-100 flex items-center gap-4 italic uppercase tracking-tighter">
                    {stock.name} <span className="text-xl text-accent font-mono not-italic">[{stock.symbol}]</span>
                    {stock.isETF && <span className="text-[10px] bg-accent text-white font-black py-1 px-3 rounded uppercase tracking-widest">ETF</span>}
                </h2>
                <div className="flex items-center gap-4 mt-2">
                    <p className="text-xs text-gray-500 font-mono uppercase tracking-widest">{stock.sector} // REGION: {stock.region}</p>
                    <div className="h-1 w-1 rounded-full bg-gray-700"></div>
                    <p className="text-xs text-gray-500 font-mono uppercase tracking-widest">STATUS: OPERATIONAL</p>
                </div>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors text-4xl font-light">&times;</button>
        </div>
        
        <div className="p-4 md:p-6 flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-800">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-3">
                <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-8">
                    <div>
                        <p className="text-5xl font-black text-gray-100 font-mono tracking-tighter leading-none">{currentPrice.toFixed(2)}</p>
                        <div className={`text-lg font-bold mt-2 ${changeColorClass} flex items-center gap-3 font-mono`}>
                            <span>{isUp ? '▲' : '▼'} {Math.abs(change).toFixed(2)}</span>
                            <span className="opacity-70">({changePercent.toFixed(2)}%)</span>
                        </div>
                    </div>
                    
                    <div className="flex flex-col gap-4 items-end">
                        <div className="flex items-center bg-black p-1 rounded-md border border-gray-700">
                             <button 
                                onClick={() => setChartType('line')}
                                className={`px-4 py-1.5 text-[10px] font-black uppercase transition-all rounded ${chartType === 'line' ? 'bg-accent text-white' : 'text-gray-600 hover:text-gray-400'}`}
                             >Line</button>
                             <button 
                                onClick={() => setChartType('candle')}
                                className={`px-4 py-1.5 text-[10px] font-black uppercase transition-all rounded ${chartType === 'candle' ? 'bg-accent text-white' : 'text-gray-600 hover:text-gray-400'}`}
                             >Candle</button>
                        </div>
                        <div className="flex items-center gap-1">
                            {(['1D', '1W', '1M', '1Y', '5Y', '10Y', '20Y', 'MAX'] as TimeRange[]).map(range => (
                                <TimeRangeButton 
                                    key={range} 
                                    label={range} 
                                    activeRange={timeRange} 
                                    onClick={setTimeRange} 
                                    disabled={range === '10Y' || range === '20Y' ? stock.history.length < 2500 : false}
                                />
                            ))}
                        </div>
                    </div>
                </div>

                <div className="h-[450px] w-full">
                    {chartType === 'candle' ? <CandlestickChart data={chartData} /> : <LineChart data={chartData} />}
                </div>
              </div>

              <div className="lg:col-span-1 space-y-6">
                {player && onPlayerBuy && onPlayerSell && (
                  <PlayerTradeControls 
                      stock={stock} 
                      player={player} 
                      onBuy={onPlayerBuy}
                      onSell={onPlayerSell}
                  />
                )}
                
                <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-5">
                  <h3 className="text-[10px] font-black text-accent uppercase tracking-[0.3em] mb-4">Market Stats</h3>
                  <div className="space-y-1">
                    <StatItem label="Volume" value={formatVolume(volume)} />
                    <StatItem label="Day Open" value={currentHistory.open.toFixed(2)} />
                    <StatItem label="Day High" value={currentHistory.high.toFixed(2)} />
                    <StatItem label="Day Low" value={currentHistory.low.toFixed(2)} />
                    <StatItem label="52W Range" value={`${low52w.toFixed(2)} - ${high52w.toFixed(2)}`} />
                    <StatItem label="Market Cap" value={formatVolume(stock.sharesOutstanding * currentPrice)} />
                  </div>
                </div>
              </div>
            </div>
             
             {stock.corporateAI && (
                <div className="mt-12 border-t border-gray-800 pt-8">
                    <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-6 text-center">Neural Network Logic // Corporate Strategy</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <NeuralNetworkVisualizer title="Equity Split Logic" weights={stock.corporateAI.splitNN.getInputLayerWeights()} />
                        <NeuralNetworkVisualizer title="Strategic Alliance" weights={stock.corporateAI.allianceNN.getInputLayerWeights()} />
                        <NeuralNetworkVisualizer title="Acquisition Protocol" weights={stock.corporateAI.acquisitionNN.getInputLayerWeights()} />
                    </div>
                </div>
            )}
        </div>
        <div className="p-4 text-[9px] text-gray-700 font-mono text-center uppercase tracking-widest border-t border-gray-800">
            Real-time data visualization provided by NeuralNet High-Frequency Terminal. Status: OK.
        </div>
      </div>
    </div>
  );
};

export default DetailedStockView;