import React, { useMemo } from 'react';
import { Investor, PortfolioItem, Stock, HyperComplexInvestorStrategy } from '../types';
import PortfolioDonutChart from './PortfolioDonutChart';
import PriceChart from './PriceChart';
import NeuralNetworkVisualizer from './NeuralNetworkVisualizer';
import { TAX_REGIMES } from '../constants';

const getSharesOwned = (item: PortfolioItem | undefined): number => {
    if (!item) return 0;
    return item.lots.reduce((sum, lot) => sum + lot.shares, 0);
};

interface InvestorCardProps {
    investor: Investor;
    stocks: Stock[];
    isHuman: boolean;
}

const InvestorCard: React.FC<InvestorCardProps> = ({ investor, stocks, isHuman }) => {
  const portfolioValue = investor.portfolio.reduce((total, item) => {
    const stock = stocks.find(s => s.symbol === item.symbol);
    const price = stock ? stock.history[stock.history.length - 1].close : 0;
    return total + getSharesOwned(item) * price;
  }, 0);
  
  const totalValue = investor.cash + portfolioValue;
  const jurisdictionInfo = TAX_REGIMES[investor.jurisdiction];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };
  
  const portfolioForChart = [
      { name: 'Cash', value: investor.cash },
      ...investor.portfolio.map(item => {
        const stock = stocks.find(s => s.symbol === item.symbol);
        const price = stock ? stock.history[stock.history.length - 1].close : 0;
        return {
          name: item.symbol,
          value: getSharesOwned(item) * price,
        };
      })
  ];

  const strategy = investor.strategy as HyperComplexInvestorStrategy;
  
  const cognitiveStats = useMemo(() => {
    if (strategy.strategyType === 'hyperComplex' && strategy.network) {
        const layers = strategy.network.layerSizes;
        const hiddenCount = layers.length - 2;
        let tier = "Standard";
        if (hiddenCount >= 5) tier = "SUPER-INTEL";
        else if (hiddenCount >= 4) tier = "INSTITUTIONAL";
        else if (hiddenCount >= 3) tier = "SOPHISTICATED";

        const inputWeights = strategy.network.getInputLayerWeights();
        return { tier, hiddenCount, inputWeights };
    }
    return null;
  }, [strategy]);

  return (
    <div className="bg-gray-800 border border-gray-700 p-4 rounded-lg flex flex-col text-sm shadow-lg hover:border-accent/50 transition-all">
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-black text-gray-100 truncate text-lg tracking-tight uppercase italic">
                {investor.name}
            </h3>
            {isHuman && <span className="text-[10px] bg-accent text-white font-black py-0.5 px-2 rounded-sm uppercase">YOU</span>}
          </div>
          <div className="flex items-center gap-3 mt-1.5">
            <span className="text-[10px] text-accent font-black tracking-widest uppercase border border-accent/30 px-1.5 rounded">
                {investor.region}
            </span>
            <div className="h-1 w-1 bg-gray-600 rounded-full"></div>
            <div 
                className="text-[10px] text-gray-400 font-mono uppercase tracking-tighter cursor-help"
                title={jurisdictionInfo.description}
            >
                TX: {investor.jurisdiction}
            </div>
          </div>
        </div>
        <div className="text-right">
            <p className="font-mono font-black text-gray-100 text-lg tracking-tighter leading-none">{formatCurrency(totalValue)}</p>
            <p className="text-[9px] text-gray-500 font-mono uppercase mt-1">Total Assets</p>
        </div>
      </div>
      
      <div className="h-20 mb-4 bg-black/30 rounded p-1">
        <PriceChart data={investor.portfolioHistory.map(p => ({ day: p.day, price: p.value }))} color="#3B82F6" />
      </div>

      <div className="grid grid-cols-2 gap-4 items-center text-xs mb-4">
        <div className="h-24">
          <PortfolioDonutChart data={portfolioForChart} />
        </div>
        <div className="bg-black/20 p-2 rounded border border-gray-700/50">
            <h4 className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-1.5">Key Holdings</h4>
            <div className="space-y-1 max-h-20 overflow-y-auto pr-1">
                <div className="flex justify-between border-b border-gray-700/30 pb-0.5">
                    <span className="font-mono text-gain text-[10px]">LIQUID_CASH</span>
                    <span className="font-mono text-[10px]">{formatCurrency(investor.cash)}</span>
                </div>
                {investor.portfolio.map(item => ({
                    symbol: item.symbol,
                    shares: getSharesOwned(item)
                })).sort((a,b) => b.shares - a.shares).slice(0, 3).map(item => (
                    <div key={item.symbol} className="flex justify-between">
                        <span className="font-mono text-accent/80 text-[10px]">{item.symbol}</span>
                        <span className="font-mono text-[10px]">{item.shares.toFixed(1)}</span>
                    </div>
                ))}
            </div>
        </div>
      </div>

      {!isHuman && strategy.strategyType === 'hyperComplex' && cognitiveStats && (
        <div className="pt-3 border-t border-gray-700/50">
             <div className="flex justify-between items-center mb-2">
                <p className="text-[10px] font-black text-gray-400 tracking-widest uppercase">Cognitive Node: {cognitiveStats.tier}</p>
                <span className="text-[9px] font-mono text-gray-600 bg-gray-900 px-1 rounded">{cognitiveStats.hiddenCount} Hidden Layers</span>
             </div>
             <NeuralNetworkVisualizer title="Primary Synapse Weights" weights={cognitiveStats.inputWeights} />
        </div>
      )}

      <div className="mt-4 pt-3 border-t border-gray-700 flex justify-between text-[10px] font-mono text-gray-500">
        <span>TAX_DEBT: {formatCurrency(investor.totalTaxesPaid)}</span>
        <span>LOSS_CARRY: {formatCurrency(investor.taxLossCarryforward)}</span>
      </div>
    </div>
  );
};

export default InvestorCard;