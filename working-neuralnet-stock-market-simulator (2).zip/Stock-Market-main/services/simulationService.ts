import { SimulationState, Stock, Investor, SimplePriceDataPoint, PortfolioItem, ActiveEvent, TrackedCorporateAction, OHLCDataPoint, Region, TrackedGeneratedArticle, RandomInvestorStrategy, HyperComplexInvestorStrategy } from '../types.ts';
import { STOCK_CONFIG, MIN_INITIAL_STOCK_PRICE, MAX_INITIAL_STOCK_PRICE, INITIAL_HISTORY_LENGTH, buildInvestors, INFLATION_RATE, TAX_CONSTANTS, CORPORATE_EVENTS_BY_SECTOR, MACRO_EVENTS, CORPORATE_TAX_RATES_BY_REGION, MIN_CORPORATE_ACTION_INTERVAL, CORPORATE_ACTION_INTERVAL_RANGE, MIN_STOCK_SPLIT_PRICE, INDICATOR_NEURONS, CORPORATE_NEURONS, generateRandomStock, TAX_REGIMES } from '../constants.tsx';
import { getImageForEvent } from './imageService.ts';
import { generateNewsArticle, createMicroLLM } from './newsGenerationService.ts';
import { NeuralNetwork } from './neuralNetwork.ts';

const rehydrateNN = (nnData: any): NeuralNetwork => {
  if (!nnData) return nnData;
  const instance = new NeuralNetwork(nnData.layerSizes || [], nnData.inputNeuronNames || []);
  Object.assign(instance, nnData);
  return instance;
};

const rehydrateState = (state: SimulationState): SimulationState => {
  state.stocks.forEach(stock => {
    if (stock.corporateAI) {
      stock.corporateAI.splitNN = rehydrateNN(stock.corporateAI.splitNN);
      stock.corporateAI.allianceNN = rehydrateNN(stock.corporateAI.allianceNN);
      stock.corporateAI.acquisitionNN = rehydrateNN(stock.corporateAI.acquisitionNN);
    }
  });
  state.investors.forEach(investor => {
    if (investor.strategy.strategyType === 'hyperComplex') {
      investor.strategy.network = rehydrateNN(investor.strategy.network);
    }
  });
  return state;
};

const generateInitialHistory = (length: number, initialPrice: number): OHLCDataPoint[] => {
  const history: OHLCDataPoint[] = [];
  let lastClose = initialPrice;
  for (let i = 0; i < length; i++) {
    const open = lastClose;
    const volume = 200000 + Math.random() * 800000;
    const priceChangePercent = (Math.random() - 0.49) * 0.05;
    const close = Math.max(0.01, open * (1 + priceChangePercent));
    const high = Math.max(open, close) * (1 + Math.random() * 0.02);
    const low = Math.min(open, close) * (1 - Math.random() * 0.02);
    history.push({ day: i + 1, open, high, low, close, volume: Math.round(volume) });
    lastClose = close;
  }
  return history;
};

const createCorporateNNs = () => {
    const inputSize = CORPORATE_NEURONS.length;
    const nnConfig = [inputSize, 5, 1];
    return {
        splitNN: new NeuralNetwork(nnConfig, CORPORATE_NEURONS),
        allianceNN: new NeuralNetwork(nnConfig, CORPORATE_NEURONS),
        acquisitionNN: new NeuralNetwork(nnConfig, CORPORATE_NEURONS),
    };
};

export const initializeState = (options: { useRealPrices?: boolean, realisticDemographics?: boolean } = {}): SimulationState => {
  const { useRealPrices = false, realisticDemographics = false } = options;
  const startDate = new Date('2024-01-01T09:30:00Z');
  const regularStockConfigs = STOCK_CONFIG.filter(s => !s.isETF);
  const etfConfigs = STOCK_CONFIG.filter(s => s.isETF);
  const usedSymbols = new Set<string>(STOCK_CONFIG.map(s => s.symbol));
  // Fix: map regular stocks providing index to generateRandomStock
  const regularStocks: Stock[] = regularStockConfigs.map((s_config, i) => {
    const initialPrice = useRealPrices ? s_config.basePrice : MIN_INITIAL_STOCK_PRICE + Math.random() * 4;
    let name = s_config.name;
    let symbol = s_config.symbol;
    if (!useRealPrices) {
        // Fix: Stock-Market-main/constants.tsx expects a number index
        const { randomName, randomSymbol } = generateRandomStock(i);
        name = randomName;
        symbol = randomSymbol;
        usedSymbols.add(symbol);
    }
    const history = generateInitialHistory(INITIAL_HISTORY_LENGTH, initialPrice);
    const { splitNN, allianceNN, acquisitionNN } = createCorporateNNs();
    return {
      symbol, name, sector: s_config.sector, region: s_config.region,
      history, isDelisted: false,
      sharesOutstanding: 100_000_000,
      corporateAI: { nextCorporateActionDay: INITIAL_HISTORY_LENGTH + 20, splitNN, allianceNN, acquisitionNN, learningRate: 0.02 },
      eps: 2.0
    };
  });
  const etfs = etfConfigs.map(s => {
      const history = generateInitialHistory(INITIAL_HISTORY_LENGTH, 100);
      return { ...s, history, isDelisted: false, sharesOutstanding: 1000000, eps: 1.5 };
  }) as Stock[];
  const stocks = [...regularStocks, ...etfs];
  const investors = buildInvestors({ realisticDemographics }).map(c => ({
      ...c, cash: c.initialCash, portfolio: [], portfolioHistory: [{day: INITIAL_HISTORY_LENGTH, value: c.initialCash}],
      taxLossCarryforward: 0, totalTaxesPaid: 0, annualNetLTCG: 0, annualNetSTCG: 0, recentTrades: []
  }));

  const regionalIndexHistory: Record<Region, SimplePriceDataPoint[]> = {
    'North America': [],
    'Europe': [],
    'Asia': [],
    'Global': []
  };

  const marketIndexHistory: SimplePriceDataPoint[] = [];

  for (let i = 0; i < INITIAL_HISTORY_LENGTH; i++) {
    const day = i + 1;
    const globalStocks = stocks.filter(s => !s.isDelisted);
    const avgPrice = globalStocks.reduce((sum, s) => sum + s.history[i].close, 0) / (globalStocks.length || 1);
    marketIndexHistory.push({ day, price: avgPrice });
    regionalIndexHistory['Global'].push({ day, price: avgPrice });

    (['North America', 'Europe', 'Asia'] as Region[]).forEach(reg => {
      const regStocks = stocks.filter(s => s.region === reg && !s.isDelisted);
      const regAvg = regStocks.reduce((sum, s) => sum + s.history[i].close, 0) / (regStocks.length || 1);
      regionalIndexHistory[reg].push({ day, price: regAvg });
    });
  }

  return {
    day: INITIAL_HISTORY_LENGTH,
    time: new Date(startDate.getTime() + INITIAL_HISTORY_LENGTH * 86400000).toISOString(),
    startDate: startDate.toISOString(),
    stocks, investors, activeEvent: null, eventHistory: [],
    marketIndexHistory, regionalIndexHistory,
    nextCorporateEventDay: INITIAL_HISTORY_LENGTH + 5, nextMacroEventDay: INITIAL_HISTORY_LENGTH + 10,
    trackedCorporateActions: [], microLLM: createMicroLLM(), trackedArticles: []
  };
};

const executeTrade = (state: SimulationState, investor: Investor, stock: Stock, shares: number, type: 'buy' | 'sell') => {
    const price = stock.history[stock.history.length-1].close;
    if (type === 'buy') {
        investor.cash -= shares * price;
        let p = investor.portfolio.find(x => x.symbol === stock.symbol);
        if (!p) { p = { symbol: stock.symbol, lots: [] }; investor.portfolio.push(p); }
        p.lots.push({ purchaseTime: state.time, purchasePrice: price, shares, purchaseIndicators: {} });
    } else {
        investor.cash += shares * price;
        investor.portfolio = investor.portfolio.filter(x => x.symbol !== stock.symbol);
    }
};

export const advanceTime = (prevState: SimulationState, seconds: number): SimulationState => {
  let state = structuredClone(prevState);
  rehydrateState(state);
  
  const startTime = new Date(state.time);
  const targetTime = new Date(startTime.getTime() + seconds * 1000);
  if (targetTime.getDate() !== startTime.getDate()) {
      state.day += 1;
      runDailyTransition(state);
  }
  state.time = targetTime.toISOString();
  return state;
};

const runDailyTransition = (state: SimulationState) => {
    state.stocks.forEach(s => {
        const last = s.history[s.history.length-1];
        const nextPrice = last.close * (1 + (Math.random() - 0.5) * 0.02);
        s.history.push({ day: state.day, open: last.close, high: Math.max(last.close, nextPrice), low: Math.min(last.close, nextPrice), close: nextPrice, volume: 100000 });
        if (s.history.length > 500) s.history.shift();
    });

    const activeStocks = state.stocks.filter(s => !s.isDelisted);
    const avgPrice = activeStocks.reduce((sum, s) => sum + s.history[s.history.length - 1].close, 0) / (activeStocks.length || 1);
    state.marketIndexHistory.push({ day: state.day, price: avgPrice });
    state.regionalIndexHistory['Global'].push({ day: state.day, price: avgPrice });

    (['North America', 'Europe', 'Asia'] as Region[]).forEach(reg => {
      const regStocks = state.stocks.filter(s => s.region === reg && !s.isDelisted);
      const regAvg = regStocks.reduce((sum, s) => sum + s.history[s.history.length - 1].close, 0) / (regStocks.length || 1);
      state.regionalIndexHistory[reg].push({ day: state.day, price: regAvg });
      if (state.regionalIndexHistory[reg].length > 500) state.regionalIndexHistory[reg].shift();
    });

    if (state.marketIndexHistory.length > 500) {
      state.marketIndexHistory.shift();
      state.regionalIndexHistory['Global'].shift();
    }

    if (state.day >= state.nextMacroEventDay) {
        const eventConfig = MACRO_EVENTS[Math.floor(Math.random() * MACRO_EVENTS.length)];
        const newEvent = addEventToHistory(state, { 
            stockSymbol: null, stockName: null, eventName: eventConfig.name, 
            description: eventConfig.description, type: eventConfig.type as any, impact: eventConfig.impact, region: eventConfig.region 
        }, ['macro']);
        state.activeEvent = newEvent;
        state.nextMacroEventDay = state.day + 15;
    }
};

const addEventToHistory = (state: SimulationState, data: any, keywords: string[]): ActiveEvent => {
    const { article } = generateNewsArticle(data, state);
    const imageUrl = getImageForEvent(article.headline, ...keywords);
    const ev = { ...data, ...article, id: Math.random().toString(), day: state.day, imageUrl };
    state.eventHistory.unshift(ev);
    return ev;
};

export const playerBuyStock = (prevState: SimulationState, pid: string, sym: string, sh: number) => {
    const s = structuredClone(prevState);
    rehydrateState(s);
    const inv = s.investors.find(i => i.id === pid);
    const st = s.stocks.find(x => x.symbol === sym);
    if (inv && st) executeTrade(s, inv, st, sh, 'buy');
    return s;
};

export const playerSellStock = (prevState: SimulationState, pid: string, sym: string, sh: number) => {
    const s = structuredClone(prevState);
    rehydrateState(s);
    const inv = s.investors.find(i => i.id === pid);
    const st = s.stocks.find(x => x.symbol === sym);
    if (inv && st) executeTrade(s, inv, st, sh, 'sell');
    return s;
};

export const isMarketOpen = (date: Date, region: Region) => true;