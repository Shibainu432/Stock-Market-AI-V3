import React, { useMemo, useState } from 'react';
import { OHLCDataPoint } from '../types.ts';

const CandlestickChart: React.FC<{ data: OHLCDataPoint[] }> = ({ data }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const { min, max, points, viewMin, viewMax } = useMemo(() => {
    if (data.length === 0) return { min: 0, max: 0, points: [], viewMin: 0, viewMax: 0 };
    
    const realMin = Math.min(...data.map(d => d.low));
    const realMax = Math.max(...data.map(d => d.high));
    const range = (realMax - realMin) || 1;
    const padding = range * 0.1;
    
    const vMin = realMin - padding;
    const vMax = realMax + padding;
    const vRange = vMax - vMin;
    
    const height = 300;
    const width = 800;
    
    const mapped = data.map((d, i) => {
      const x = (i / data.length) * width;
      const getY = (val: number) => height - ((val - vMin) / vRange) * height;
      
      return {
        x,
        highY: getY(d.high),
        lowY: getY(d.low),
        openY: getY(d.open),
        closeY: getY(d.close),
        isUp: d.close >= d.open,
        raw: d
      };
    });
    
    return { min: realMin, max: realMax, points: mapped, viewMin: vMin, viewMax: vMax };
  }, [data]);

  if (data.length < 2) {
    return (
      <div className="w-full h-full flex items-center justify-center text-xs text-gray-500 font-mono italic">
        INSUFFICIENT DATA PACKETS FOR VISUALIZATION
      </div>
    );
  }

  const candleWidth = (800 / data.length) * 0.7;

  return (
    <div className="relative w-full h-full bg-black/20 rounded border border-gray-800 p-2 overflow-hidden">
      <svg viewBox="0 0 800 300" preserveAspectRatio="none" className="w-full h-full overflow-visible">
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map(p => (
          <line 
            key={p} 
            x1="0" y1={p * 300} x2="800" y2={p * 300} 
            stroke="#1f2937" strokeWidth="1" strokeDasharray="4 4" 
          />
        ))}
        
        {points.map((p, i) => (
          <g key={i}>
            {/* Wick */}
            <line 
              x1={p.x + candleWidth / 2} y1={p.highY} 
              x2={p.x + candleWidth / 2} y2={p.lowY} 
              stroke={p.isUp ? '#22c55e' : '#ef4444'} 
              strokeWidth="1.5"
            />
            {/* Body */}
            <rect
              x={p.x}
              y={Math.min(p.openY, p.closeY)}
              width={candleWidth}
              height={Math.max(1, Math.abs(p.openY - p.closeY))}
              fill={p.isUp ? '#22c55e' : '#ef4444'}
              opacity={hoveredIdx === i ? 1 : 0.8}
            />
            {/* Hover Trigger Overlay */}
            <rect
              x={p.x - candleWidth * 0.15}
              y="0"
              width={candleWidth * 1.3}
              height="300"
              fill="transparent"
              onMouseEnter={() => setHoveredIdx(i)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="cursor-crosshair"
            />
          </g>
        ))}
      </svg>

      {/* Tooltip */}
      {hoveredIdx !== null && (
        <div className="absolute top-4 right-4 bg-gray-900/95 border border-gray-700 p-3 rounded shadow-xl font-mono text-[10px] z-10 pointer-events-none">
          <div className="text-accent mb-1 font-bold">SESSION DATA: DAY {data[hoveredIdx].day}</div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            <span className="text-gray-500">OPEN:</span> <span className="text-right">{data[hoveredIdx].open.toFixed(2)}</span>
            <span className="text-gray-500">HIGH:</span> <span className="text-right">{data[hoveredIdx].high.toFixed(2)}</span>
            <span className="text-gray-500">LOW:</span> <span className="text-right">{data[hoveredIdx].low.toFixed(2)}</span>
            <span className="text-gray-500">CLOSE:</span> <span className="text-right font-bold">{data[hoveredIdx].close.toFixed(2)}</span>
          </div>
          <div className={`mt-2 pt-2 border-t border-gray-800 font-bold ${data[hoveredIdx].close >= data[hoveredIdx].open ? 'text-gain' : 'text-loss'}`}>
            CHANGE: {(data[hoveredIdx].close - data[hoveredIdx].open).toFixed(2)}
          </div>
        </div>
      )}

      {/* Axis Labels */}
      <div className="absolute left-2 top-0 bottom-0 flex flex-col justify-between py-2 text-[8px] text-gray-600 font-mono pointer-events-none">
        <span>{viewMax.toFixed(0)}</span>
        <span>{((viewMax + viewMin) / 2).toFixed(0)}</span>
        <span>{viewMin.toFixed(0)}</span>
      </div>
    </div>
  );
};

export default CandlestickChart;