/**
 * CONCEPT VECTORS
 * Each category maps semantic concepts to visual search clusters.
 * The "Neural Selector" scores the news text against these clusters.
 */
const VISUAL_CONCEPTS: Record<string, { weight: number; search: string; tokens: string[] }> = {
    'FUTURE_TECH': {
        weight: 10,
        search: 'futuristic technology, hologram, blue neon computer',
        tokens: ['ai', 'quantum', 'holographic', 'neural', 'chip', 'cyber', 'software', 'compute', 'data', 'server', 'semiconductor']
    },
    'SPACE_ECONOMY': {
        weight: 12,
        search: 'space station, mars colony, asteroid mining',
        tokens: ['asteroid', 'lunar', 'mars', 'orbital', 'space', 'mining', 'rocket', 'satellite', 'planet', 'galaxy', 'interplanetary']
    },
    'GLOBAL_FINANCE': {
        weight: 8,
        search: 'wall street, futuristic stock exchange, candle chart',
        tokens: ['bank', 'finance', 'market', 'index', 'invest', 'portfolio', 'sovereign', 'currency', 'tax', 'earnings', 'equity', 'bond', 'broker']
    },
    'TOKYO_TECH': {
        weight: 11,
        search: 'futuristic tokyo, shibuya neon, japanese technology',
        tokens: ['tokyo', 'japan', 'nikkei', 'yen', 'asia', 'shippu', 'toyota']
    },
    'LONDON_CITY': {
        weight: 11,
        search: 'futuristic london, the shard, fog neon city',
        tokens: ['london', 'uk', 'ftse', 'europe', 'pound', 'sterling', 'ecb', 'brussels', 'eu']
    },
    'NYC_METROPOLIS': {
        weight: 11,
        search: 'futuristic nyc, cyber times square, empire state building',
        tokens: ['nyc', 'new york', 'nasdaq', 'dow jones', 'america', 'usa', 'federal reserve', 'wall street']
    },
    'BIO_GENETICS': {
        weight: 11,
        search: 'biotechnology laboratory, dna helix, medical tech',
        tokens: ['health', 'biotech', 'gene', 'vaccine', 'dna', 'medical', 'pharma', 'telomere', 'nanobot', 'clinical', 'hospital']
    },
    'GREEN_ENERGY': {
        weight: 9,
        search: 'fusion reactor core, clean energy solar, wind turbine neon',
        tokens: ['energy', 'fusion', 'grid', 'solar', 'wind', 'carbon', 'capture', 'battery', 'lithium', 'graphene', 'renewable']
    },
    'CYBER_CONFLICT': {
        weight: 15,
        search: 'cyberwar, hacking, data security breach red',
        tokens: ['breach', 'exploit', 'hack', 'vulnerability', 'warfare', 'cyberattack', 'ransomware', 'malware', 'security', 'zero-day']
    },
    'GLOBAL_DISASTER': {
        weight: 14,
        search: 'environmental crisis, natural disaster, apocalyptic storm',
        tokens: ['hurricane', 'earthquake', 'wildfire', 'leak', 'blackout', 'crash', 'collapse', 'famine', 'flooding', 'disaster', 'heat dome', 'tsunami']
    },
    'POLITICAL_UPHEAVAL': {
        weight: 13,
        search: 'political protest, futuristic parliament, government rally',
        tokens: ['political', 'referendum', 'election', 'independence', 'treaty', 'act', 'law', 'protest', 'activism', 'governance', 'scandal', 'sovereignty']
    },
    'FUTURE_SOCIETY': {
        weight: 9,
        search: 'futuristic crowd, cyber citizens, high tech city life',
        tokens: ['social', 'movement', 'citizen', 'human', 'labor', 'ethics', 'population', 'worker', 'lifestyle', 'culture', 'public']
    }
};

/**
 * AI IMAGE SELECTOR ALGORITHM
 */
export const getImageForEvent = (headline: string, ...extraKeywords: string[]): string => {
    const text = (headline + " " + extraKeywords.join(" ")).toLowerCase();
    const scores: Record<string, number> = {};

    Object.keys(VISUAL_CONCEPTS).forEach(k => scores[k] = 0);

    Object.entries(VISUAL_CONCEPTS).forEach(([key, concept]) => {
        concept.tokens.forEach(token => {
            if (text.includes(token)) {
                scores[key] += concept.weight;
            }
        });
    });

    let bestCategory = 'GLOBAL_FINANCE';
    let maxScore = 0;

    Object.entries(scores).forEach(([cat, score]) => {
        if (score > maxScore) {
            maxScore = score;
            bestCategory = cat;
        }
    });

    let finalSearch = VISUAL_CONCEPTS[bestCategory].search;
    
    // Sentiment Fallback
    if (maxScore === 0) {
        if (text.includes('surge') || text.includes('boom') || text.includes('win') || text.includes('rally')) {
            finalSearch = "growth success, mountain sunrise";
        } else if (text.includes('fall') || text.includes('drop') || text.includes('crash') || text.includes('tumble')) {
            finalSearch = "economic crisis, red stock chart";
        }
    }

    return `https://images.unsplash.com/featured/?${encodeURIComponent(finalSearch)}`;
};