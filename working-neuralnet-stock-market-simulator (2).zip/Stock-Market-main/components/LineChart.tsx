import React, { useMemo, useState } from 'react';
import { OHLCDataPoint } from '../types.ts';

const LineChart: React.FC<{ data: OHLCDataPoint[] }> = ({ data }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const { path, areaPath, min, max, points } = useMemo(() => {
    if (data.length < 2) return { path: '', areaPath: '', min: 0, max: 0, points: [] };
    
    const prices = data.map(d => d.close);
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const range = (max - min) || 1;
    const padding = range * 0.1;
    
    const viewMin = min - padding;
    const viewMax = max + padding;
    const viewRange = viewMax - viewMin;
    
    const height = 300;
    const width = 800;
    
    const mappedPoints = data.map((d, i) => ({
      x: (i / (data.length - 1)) * width,
      y: height - ((d.close - viewMin) / viewRange) * height,
      raw: d
    }));

    const linePath = mappedPoints.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
    const fillPath = `${linePath} L ${width} ${height} L 0 ${height} Z`;
    
    return { path: linePath, areaPath: fillPath, min: viewMin, max: viewMax, points: mappedPoints };
  }, [data]);

  if (data.length < 2) return <div className="flex items-center justify-center h-full text-gray-500 font-mono italic">INITIALIZING DATA STREAM...</div>;

  return (
    <div className="relative w-full h-full bg-black/20 rounded border border-gray-800 p-2 overflow-hidden group">
      <svg viewBox="0 0 800 300" preserveAspectRatio="none" className="w-full h-full overflow-visible">
        <defs>
          <linearGradient id="lineGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
          </linearGradient>
        </defs>
        
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map(p => (
          <line 
            key={p} 
            x1="0" y1={p * 300} x2="800" y2={p * 300} 
            stroke="#1f2937" strokeWidth="1" strokeDasharray="4 4" 
          />
        ))}

        <path d={areaPath} fill="url(#lineGradient)" />
        <path d={path} fill="none" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

        {/* Hover tracker */}
        {hoveredIdx !== null && (
          <g>
            <line 
              x1={points[hoveredIdx].x} y1="0" 
              x2={points[hoveredIdx].x} y2="300" 
              stroke="#4b5563" strokeWidth="1" strokeDasharray="2 2" 
            />
            <circle cx={points[hoveredIdx].x} cy={points[hoveredIdx].y} r="4" fill="#3b82f6" />
          </g>
        )}

        {/* Interaction zones */}
        {points.map((p, i) => (
          <rect
            key={i}
            x={p.x - (800 / data.length / 2)}
            y="0"
            width={800 / data.length}
            height="300"
            fill="transparent"
            onMouseEnter={() => setHoveredIdx(i)}
            onMouseLeave={() => setHoveredIdx(null)}
            className="cursor-crosshair"
          />
        ))}
      </svg>

      {/* Tooltip */}
      {hoveredIdx !== null && (
        <div className="absolute top-4 right-4 bg-gray-900/95 border border-gray-700 p-3 rounded shadow-xl font-mono text-[10px] z-10 pointer-events-none">
          <div className="text-accent mb-1 font-bold tracking-widest uppercase">MARKET TICK // DAY {data[hoveredIdx].day}</div>
          <div className="flex justify-between gap-4">
            <span className="text-gray-500">VALUATION:</span>
            <span className="text-gray-100 font-bold">{data[hoveredIdx].close.toFixed(2)}</span>
          </div>
        </div>
      )}

      {/* Axis Labels */}
      <div className="absolute left-2 top-0 bottom-0 flex flex-col justify-between py-2 text-[8px] text-gray-600 font-mono pointer-events-none uppercase tracking-tighter">
        <span>{max.toFixed(0)}</span>
        <span>{((max + min) / 2).toFixed(0)}</span>
        <span>{min.toFixed(0)}</span>
      </div>
    </div>
  );
};

export default LineChart;