import { GoogleGenAI, Type } from "@google/genai";
import { ActiveEvent, SimulationState, MicroLLM } from '../types.ts';

export type Article = { headline: string; summary: string; fullText: string };
export type GenerationResult = { article: Article; generatedText: string };

const TRAINING_CORPUS = `
REUTERS (LONDON) — Equity markets showed resilience on Friday as institutional desks moved aggressively into cyclical sectors following a surprise cooling in US CPI data.
BLOOMBERG (NEW YORK) — The Nasdaq 100 hit fresh all-time highs as semiconductor heavyweights surged on reports of an infrastructure bottleneck loosening in the APAC region.
CNBC (TOKYO) — Nikkei 225 traders are bracing for a period of heightened volatility as the Bank of Japan signals a potential pivot away from ultra-loose monetary policy.
WSJ (WASHINGTON) — Treasury yields flattened across the curve as investors parsed the latest Fed minutes, which revealed a deepening divide over the timing of future rate cuts.
`;

const MARKOV_ORDER = 6;

export const createMicroLLM = (): MicroLLM => {
    const transitionTable: Record<string, Record<string, number>> = {};
    const corpus = TRAINING_CORPUS;

    for (let i = 0; i < corpus.length - MARKOV_ORDER; i++) {
        const gram = corpus.substring(i, i + MARKOV_ORDER);
        const nextChar = corpus.charAt(i + MARKOV_ORDER);
        
        if (!transitionTable[gram]) {
            transitionTable[gram] = {};
        }
        if (!transitionTable[gram][nextChar]) {
            transitionTable[gram][nextChar] = 0;
        }
        transitionTable[gram][nextChar]++;
    }
    return { transitionTable, order: MARKOV_ORDER };
};

export const generateNewsArticleGemini = async (event: ActiveEvent, state: SimulationState): Promise<Article> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
        const prompt = `Act as a senior investigative global reporter for a prestigious international news terminal (like Reuters, Bloomberg, or Al Jazeera). 
        Write a hyper-realistic, sophisticated news report on the following event in the year 2050. 
        Note: This is NOT just a financial report; it's a world news report that MUST conclude with its impact on the global markets.

        EVENT CONTEXT:
        - Event Name: ${event.eventName}
        - Event Type: ${event.type} (e.g., political, disaster, positive, negative)
        - Brief Description: ${event.description}
        - Simulation Day: ${state.day}
        - Region: ${event.region || 'Global'}
        - Market Data Context: Current Market Index is at ${state.marketIndexHistory.length > 0 ? state.marketIndexHistory[state.marketIndexHistory.length - 1].price.toFixed(2) : '1000'}.

        REPORTING REQUIREMENTS:
        1. HEADLINE: Punchy, urgent, global-impact style.
        2. SUMMARY: A concise 2-sentence breakdown for mobile news alerts.
        3. MAIN BODY:
           - Provide context: Explain the 'why' and 'how' of the event.
           - If it's a WEATHER/ENVIRONMENTAL event: Describe the scale (e.g., "satellite imagery confirms 100ft surge levels").
           - If it's a POLITICAL event: Quote a fictional global leader or a citizen group (e.g., "The Martian Freedom Front stated...").
           - If it's a SOCIAL event: Describe the street-level impact or the change in human behavior.
           - MANDATORY: Connect the event to the financial markets. How are algorithmic trading bots reacting? Are institutional investors fleeing to 'safe haven' assets like Fusion Energy credits or Lunar Real Estate?
        
        TONE: Sophisticated, futuristic, authoritative, and analytical.
        FORMAT: JSON ONLY.`;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        headline: { type: Type.STRING },
                        summary: { type: Type.STRING },
                        fullText: { type: Type.STRING }
                    },
                    required: ["headline", "summary", "fullText"]
                }
            }
        });

        const text = response.text;
        if (!text) throw new Error("Empty response");
        
        return JSON.parse(text);
    } catch (err) {
        console.warn("Gemini failing, falling back to local wire template:", err);
        return {
            headline: `GLOBAL ALERT: ${event.eventName}`,
            summary: `World leaders and market participants are responding to ${event.eventName} as systemic shifts accelerate.`,
            fullText: `[INTERNATIONAL FEED] — Data streams originating from the ${event.region || 'Global'} hub indicate a significant escalation regarding ${event.description}. \n\n"The implications are far-reaching," noted a representative from the NeuralNet Global Intelligence Council. "We are seeing immediate ripple effects across socio-political frameworks." \n\nFrom a financial perspective, algorithmic desks in Tokyo and New York have entered a state of high-frequency reassessment. Technical analysts report a flight to stability, with the current market index of ${state.marketIndexHistory.length > 0 ? state.marketIndexHistory[state.marketIndexHistory.length - 1].price.toFixed(2) : '1000'} serving as a critical psychological support level.`
        };
    }
};

export const generateNewsArticle = (event: ActiveEvent, state: SimulationState): GenerationResult => {
    const headline = `TERMINAL UPDATE: ${event.eventName}`;
    const summary = `Market desks are monitoring ${event.eventName} for immediate systemic implications across the ${event.region || 'Global'} benchmark.`;
    const fullText = `[AUTOMATED DATA FEED] — Market participants are currently parsing reports of ${event.description}. Early indicators from the ${event.region || 'Global'} sector suggest a ${event.type} bias in short-term positioning. Institutional desks report high trade volume at key psychological price points as the index adjusts to the new fundamental backdrop.`;

    return { 
        article: { headline, summary, fullText }, 
        generatedText: fullText 
    };
};

export const learnFromArticleOutcome = (llm: MicroLLM, generatedText: string, outcome: number): MicroLLM => {
    return llm; 
};

export const refineLLMWithCorpus = (llm: MicroLLM): MicroLLM => llm;