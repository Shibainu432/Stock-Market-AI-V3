import React, { useMemo } from 'react';
import { SimplePriceDataPoint } from '../types.ts';

interface PriceChartProps {
  data: SimplePriceDataPoint[];
  color: string;
  precision?: number;
}

const PriceChart: React.FC<PriceChartProps> = ({ data, color }) => {
  const sampledData = useMemo(() => {
    if (data.length <= 200) return data;
    // Downsample for performance on long histories (sparklines)
    const step = Math.floor(data.length / 100);
    const result = [];
    for (let i = 0; i < data.length; i += step) {
      result.push(data[i]);
    }
    // Ensure the last point is always included
    if (result[result.length - 1] !== data[data.length - 1]) {
        result.push(data[data.length - 1]);
    }
    return result;
  }, [data]);

  const pathData = useMemo(() => {
    if (sampledData.length < 2) return '';
    
    const minPrice = Math.min(...sampledData.map(d => d.price));
    const maxPrice = Math.max(...sampledData.map(d => d.price));
    const range = maxPrice - minPrice || 1;
    
    const width = 100;
    const height = 40;
    
    return sampledData.map((d, i) => {
      const x = (i / (sampledData.length - 1)) * width;
      const y = height - ((d.price - minPrice) / range) * height;
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');
  }, [sampledData]);

  if (sampledData.length < 2) return null;

  return (
    <svg 
      viewBox="0 0 100 40" 
      preserveAspectRatio="none" 
      className="w-full h-full"
      style={{ overflow: 'visible' }}
    >
      <path
        d={pathData}
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export default PriceChart;