import { SimulationState, Stock, Investor, SimplePriceDataPoint, PortfolioItem, ActiveEvent, TrackedCorporateAction, OHLCDataPoint, Region, TrackedGeneratedArticle, RandomInvestorStrategy, HyperComplexInvestorStrategy } from '../types.ts';
import { STOCK_CONFIG, MIN_INITIAL_STOCK_PRICE, MAX_INITIAL_STOCK_PRICE, INITIAL_HISTORY_LENGTH, REAL_DATA_HISTORY_LENGTH, buildInvestors, INFLATION_RATE, TAX_CONSTANTS, CORPORATE_EVENTS_BY_SECTOR, MACRO_EVENTS, CORPORATE_TAX_RATES_BY_REGION, MIN_CORPORATE_ACTION_INTERVAL, CORPORATE_ACTION_INTERVAL_RANGE, MIN_STOCK_SPLIT_PRICE, INDICATOR_NEURONS, CORPORATE_NEURONS, generateRandomStock, TAX_REGIMES, TOTAL_SIMULATED_STOCKS } from '../constants.tsx';
import { getImageForEvent } from './imageService.ts';
import { generateNewsArticle, createMicroLLM } from './newsGenerationService.ts';
import { NeuralNetwork } from './neuralNetwork.ts';

const rehydrateNN = (nnData: any): NeuralNetwork => {
  if (!nnData) return nnData;
  const instance = new NeuralNetwork(nnData.layerSizes || [], nnData.inputNeuronNames || []);
  Object.assign(instance, nnData);
  return instance;
};

const rehydrateState = (state: SimulationState): SimulationState => {
  state.stocks.forEach(stock => {
    if (stock.corporateAI) {
      stock.corporateAI.splitNN = rehydrateNN(stock.corporateAI.splitNN);
      stock.corporateAI.allianceNN = rehydrateNN(stock.corporateAI.allianceNN);
      stock.corporateAI.acquisitionNN = rehydrateNN(stock.corporateAI.acquisitionNN);
    }
  });
  state.investors.forEach(investor => {
    if (investor.strategy.strategyType === 'hyperComplex') {
      investor.strategy.network = rehydrateNN(investor.strategy.network);
    }
  });
  return state;
};

const generateInitialHistory = (length: number, initialPrice: number): OHLCDataPoint[] => {
  const history: OHLCDataPoint[] = [];
  let lastClose = initialPrice;
  let regimeDaysRemaining = 0;
  let regimeBias = 0;
  let regimeVolatility = 0.01;

  for (let i = 0; i < length; i++) {
    if (regimeDaysRemaining <= 0) {
        regimeDaysRemaining = 60 + Math.floor(Math.random() * 500);
        regimeBias = (Math.random() - 0.5) * 0.1;
        regimeVolatility = 0.005 + Math.random() * 0.015;
    }
    const open = lastClose;
    const baseVolume = 200000 + Math.random() * 800000;
    const randomness = (Math.random() - 0.5) * 2 * regimeVolatility;
    const drift = regimeBias * 0.05;
    const priceChangePercent = randomness + drift;
    const close = Math.max(0.01, open * (1 + priceChangePercent));
    const high = Math.max(open, close) * (1 + Math.random() * regimeVolatility);
    const low = Math.min(open, close) * (1 - Math.random() * regimeVolatility);
    const volumeModifier = 1 + Math.abs(priceChangePercent) * 20;
    const volume = Math.round(baseVolume * volumeModifier);
    history.push({ day: i + 1, open, high, low, close, volume });
    lastClose = close;
    regimeDaysRemaining--;
  }
  return history;
};

const createCorporateNNs = () => {
    const inputSize = CORPORATE_NEURONS.length;
    const nnConfig = [inputSize, 5, 1];
    return {
        splitNN: new NeuralNetwork(nnConfig, CORPORATE_NEURONS),
        allianceNN: new NeuralNetwork(nnConfig, CORPORATE_NEURONS),
        acquisitionNN: new NeuralNetwork(nnConfig, CORPORATE_NEURONS),
    };
};

export const initializeState = (options: { useRealPrices?: boolean, realisticDemographics?: boolean } = {}): SimulationState => {
  const { useRealPrices = false, realisticDemographics = false } = options;
  const historyLength = useRealPrices ? REAL_DATA_HISTORY_LENGTH : INITIAL_HISTORY_LENGTH;
  const startDate = new Date(useRealPrices ? '2004-01-01T09:30:00Z' : '2024-01-01T09:30:00Z');
  
  const stocks: Stock[] = [];
  const usedSymbols = new Set<string>();

  STOCK_CONFIG.forEach(s_config => {
    const initialPrice = useRealPrices ? s_config.basePrice * (0.5 + Math.random()) : MIN_INITIAL_STOCK_PRICE + Math.random() * 4;
    const history = generateInitialHistory(historyLength, initialPrice);
    const { splitNN, allianceNN, acquisitionNN } = createCorporateNNs();
    stocks.push({
      symbol: s_config.symbol, 
      name: s_config.name, 
      sector: s_config.sector, 
      region: s_config.region,
      history, 
      isDelisted: false,
      sharesOutstanding: 100_000_000,
      corporateAI: { nextCorporateActionDay: historyLength + 20, splitNN, allianceNN, acquisitionNN, learningRate: 0.02 },
      eps: 2.0,
      isETF: s_config.isETF
    });
    usedSymbols.add(s_config.symbol);
  });

  const SECTORS = ['Technology', 'Health', 'Energy', 'Finance', 'Industrials'];
  const REGIONS: Region[] = ['North America', 'Europe', 'Asia'];

  for (let i = stocks.length; i < TOTAL_SIMULATED_STOCKS; i++) {
    const { randomName, randomSymbol } = generateRandomStock(usedSymbols);
    const hLen = Math.min(historyLength, 252); 
    const initialPrice = 5 + Math.random() * 50;
    const history = generateInitialHistory(hLen, initialPrice);
    
    stocks.push({
      symbol: randomSymbol,
      name: randomName,
      sector: SECTORS[i % SECTORS.length],
      region: REGIONS[i % REGIONS.length],
      history,
      isDelisted: false,
      sharesOutstanding: 1_000_000 + Math.random() * 50_000_000,
      eps: 0.1 + Math.random() * 5
    });
    usedSymbols.add(randomSymbol);
  }

  const investors = buildInvestors({ realisticDemographics }).map(c => ({
      ...c, cash: c.initialCash, portfolio: [], portfolioHistory: [{day: historyLength, value: c.initialCash}],
      taxLossCarryforward: 0, totalTaxesPaid: 0, annualNetLTCG: 0, annualNetSTCG: 0, recentTrades: []
  }));

  const marketIndexHistory: SimplePriceDataPoint[] = [];
  const regionalIndexHistory: Record<Region, SimplePriceDataPoint[]> = { 'North America': [], 'Europe': [], 'Asia': [], 'Global': [] };

  for (let i = 0; i < historyLength; i++) {
    const day = i + 1;
    const indexStocks = stocks.slice(0, 50);
    const avgPrice = indexStocks.reduce((sum, s) => {
        const point = s.history[i] || s.history[s.history.length-1];
        return sum + point.close;
    }, 0) / (indexStocks.length || 1);
    marketIndexHistory.push({ day, price: avgPrice });
    regionalIndexHistory['Global'].push({ day, price: avgPrice });
  }

  return {
    day: historyLength,
    time: new Date(startDate.getTime() + historyLength * 86400000).toISOString(),
    startDate: startDate.toISOString(),
    stocks, investors, activeEvent: null, eventHistory: [],
    marketIndexHistory, regionalIndexHistory,
    nextCorporateEventDay: historyLength + 5, nextMacroEventDay: historyLength + 10,
    trackedCorporateActions: [], microLLM: createMicroLLM(), trackedArticles: []
  };
};

const executeTrade = (state: SimulationState, investor: Investor, stock: Stock, shares: number, type: 'buy' | 'sell') => {
    const price = stock.history[stock.history.length-1].close;
    if (type === 'buy') {
        investor.cash -= shares * price;
        let p = investor.portfolio.find(x => x.symbol === stock.symbol);
        if (!p) { p = { symbol: stock.symbol, lots: [] }; investor.portfolio.push(p); }
        p.lots.push({ purchaseTime: state.time, purchasePrice: price, shares, purchaseIndicators: {} });
    } else {
        investor.cash += shares * price;
        investor.portfolio = investor.portfolio.filter(x => x.symbol !== stock.symbol);
    }
};

export const advanceTime = (prevState: SimulationState, seconds: number): SimulationState => {
  let state = structuredClone(prevState);
  rehydrateState(state);
  
  const startTime = new Date(state.time);
  const targetTime = new Date(startTime.getTime() + seconds * 1000);
  if (targetTime.getDate() !== startTime.getDate()) {
      state.day += 1;
      runDailyTransition(state);
  }
  state.time = targetTime.toISOString();
  return state;
};

const runDailyTransition = (state: SimulationState) => {
    // Process news pulses
    let globalPoliticalScore = 0;
    let regionalDisruption: Record<Region, number> = { 'North America': 0, 'Europe': 0, 'Asia': 0, 'Global': 0 };

    if (state.activeEvent) {
        const ev = state.activeEvent;
        if (ev.type === 'political') globalPoliticalScore = (ev.impact as number || 1) - 1;
        if (ev.type === 'disaster' && ev.region) regionalDisruption[ev.region as Region] = (ev.impact as number || 1) - 1;
    }

    // Daily Market Tick
    for (let i = 0; i < state.stocks.length; i++) {
        const s = state.stocks[i];
        const last = s.history[s.history.length-1];
        
        // News modifiers
        let newsBias = 0;
        if (state.activeEvent && (state.activeEvent.region === s.region || state.activeEvent.region === 'Global')) {
            newsBias = ((state.activeEvent.impact as number || 1) - 1) * 0.1;
        }

        const nextPrice = last.close * (1 + (Math.random() - 0.5) * 0.02 + newsBias);
        s.history.push({ day: state.day, open: last.close, high: Math.max(last.close, nextPrice), low: Math.min(last.close, nextPrice), close: nextPrice, volume: 100000 });
        if (s.history.length > 5000) s.history.shift(); 
    }

    // AI Investor Decision Logic
    state.investors.forEach(inv => {
        if (inv.isHuman) return;
        
        if (inv.strategy.strategyType === 'hyperComplex') {
            const net = inv.strategy.network;
            // Regional/News Affinity Modulators
            const regionMatch = state.activeEvent?.region === inv.region;
            const regionMod = regionMatch ? 2.5 : 0.5;
            
            // Build input vector including news neurons
            const inputs = [
                Math.random(), Math.random(), Math.random(), Math.random(), // Technicals (Placeholder)
                globalPoliticalScore, 
                regionalDisruption[inv.region], 
                regionMatch ? 1 : 0, // News proximity
                Math.random() // Social Volatility
            ];

            const decision = net.feedForward(inputs)[0];
            if (Math.abs(decision) > 0.8) {
                // Execute logical trade...
            }
        }
    });

    const indexStocks = state.stocks.slice(0, 50);
    const avgPrice = indexStocks.reduce((sum, s) => sum + s.history[s.history.length - 1].close, 0) / (indexStocks.length || 1);
    state.marketIndexHistory.push({ day: state.day, price: avgPrice });
    state.regionalIndexHistory['Global'].push({ day: state.day, price: avgPrice });

    if (state.day >= state.nextMacroEventDay) {
        const eventConfig = MACRO_EVENTS[Math.floor(Math.random() * MACRO_EVENTS.length)];
        const newEvent = addEventToHistory(state, { 
            stockSymbol: null, stockName: null, eventName: eventConfig.name, 
            description: eventConfig.description, type: eventConfig.type as any, impact: eventConfig.impact, region: eventConfig.region 
        }, ['macro']);
        state.activeEvent = newEvent;
        state.nextMacroEventDay = state.day + 15;
    }
};

const addEventToHistory = (state: SimulationState, data: any, keywords: string[]): ActiveEvent => {
    const { article } = generateNewsArticle(data, state);
    const imageUrl = getImageForEvent(article.headline, ...keywords);
    const ev = { ...data, ...article, id: Math.random().toString(), day: state.day, imageUrl };
    state.eventHistory.unshift(ev);
    return ev;
};

export const playerBuyStock = (prevState: SimulationState, pid: string, sym: string, sh: number) => {
    const s = structuredClone(prevState);
    rehydrateState(s);
    const inv = s.investors.find(i => i.id === pid);
    const st = s.stocks.find(x => x.symbol === sym);
    if (inv && st) executeTrade(s, inv, st, sh, 'buy');
    return s;
};

export const playerSellStock = (prevState: SimulationState, pid: string, sym: string, sh: number) => {
    const s = structuredClone(prevState);
    rehydrateState(s);
    const inv = s.investors.find(i => i.id === pid);
    const st = s.stocks.find(x => x.symbol === sym);
    if (inv && st) executeTrade(s, inv, st, sh, 'sell');
    return s;
};

export const isMarketOpen = (date: Date, region: Region) => true;